import Link from "next/link"
import { redirect } from "next/navigation"
import {
  Inbox,
  Wallet,
  FlaskConical,
  Zap,
  Lock,
  ArrowRight,
  Check,
} from "lucide-react"
import { getSession } from "@/lib/session"
import { Button } from "@/components/ui/button"
import { Logo } from "@/components/logo"
import { SiteHeader } from "@/components/landing/site-header"
import { PhoneMockup } from "@/components/landing/phone-mockup"

const features = [
  {
    icon: Inbox,
    title: "Simulated SMS inbox",
    body: "Receive realistic OTP and verification messages on reserved test numbers — no carriers involved.",
  },
  {
    icon: FlaskConical,
    title: "Test projects",
    body: "Spin up isolated projects per app or environment and keep their message streams separate.",
  },
  {
    icon: Wallet,
    title: "Prepaid wallet",
    body: "Top up a simple wallet and track every credit and debit from one clean dashboard.",
  },
  {
    icon: Zap,
    title: "Instant delivery",
    body: "Generate a new simulated message in one tap and watch it land in your inbox immediately.",
  },
]

const steps = [
  { n: "1", title: "Create a project", body: "Get a reserved test phone number for your app." },
  { n: "2", title: "Trigger a message", body: "Simulate an incoming OTP for that number." },
  { n: "3", title: "Read the code", body: "The parsed code appears in your inbox instantly." },
]

export default async function LandingPage() {
  const session = await getSession()
  if (session?.user) redirect("/dashboard")

  return (
    <div className="flex min-h-dvh flex-col">
      <SiteHeader />

      <main className="flex-1">
        {/* Hero */}
        <section className="mx-auto w-full max-w-5xl px-4 pt-10 pb-14 md:pt-16">
          <div className="grid items-center gap-10 md:grid-cols-2">
            <div className="flex flex-col items-start gap-5 text-balance">
              <span className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary/60 px-3 py-1 text-xs font-medium text-secondary-foreground">
                <span className="size-1.5 rounded-full bg-success" />
                Built for developers &amp; QA teams
              </span>
              <h1 className="text-4xl font-bold leading-[1.1] tracking-tight md:text-5xl">
                Test SMS &amp; OTP flows without the guesswork
              </h1>
              <p className="text-pretty text-base leading-relaxed text-muted-foreground md:text-lg">
                OlaqVerify gives you simulated test numbers and realistic verification
                messages so you can build and QA your sign-in flows end to end. A safe
                sandbox — never a bypass for real verification systems.
              </p>
              <div className="flex w-full flex-col gap-3 sm:w-auto sm:flex-row">
                <Button asChild size="lg" className="group">
                  <Link href="/sign-up">
                    Start testing free
                    <ArrowRight className="transition-transform group-hover:translate-x-0.5" />
                  </Link>
                </Button>
                <Button asChild size="lg" variant="outline">
                  <Link href="/sign-in">I have an account</Link>
                </Button>
              </div>
              <ul className="flex flex-wrap gap-x-5 gap-y-2 pt-1 text-sm text-muted-foreground">
                {["No credit card", "Simulated data only", "Cancel anytime"].map((t) => (
                  <li key={t} className="inline-flex items-center gap-1.5">
                    <Check className="size-4 text-success" /> {t}
                  </li>
                ))}
              </ul>
            </div>
            <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
              <PhoneMockup />
            </div>
          </div>
        </section>

        {/* Features */}
        <section className="border-t border-border bg-secondary/30">
          <div className="mx-auto w-full max-w-5xl px-4 py-14">
            <div className="mx-auto max-w-xl text-center">
              <h2 className="text-2xl font-bold tracking-tight md:text-3xl text-balance">
                Everything you need to test verification
              </h2>
              <p className="mt-3 text-pretty text-muted-foreground">
                A focused toolkit for exercising the messaging paths your users depend on.
              </p>
            </div>
            <div className="mt-10 grid gap-4 sm:grid-cols-2">
              {features.map((f) => (
                <div
                  key={f.title}
                  className="rounded-2xl border border-border bg-card p-5 transition-shadow hover:shadow-lg hover:shadow-primary/5"
                >
                  <div className="grid size-11 place-items-center rounded-xl bg-accent text-accent-foreground">
                    <f.icon className="size-5" />
                  </div>
                  <h3 className="mt-4 font-semibold">{f.title}</h3>
                  <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                    {f.body}
                  </p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* How it works */}
        <section className="mx-auto w-full max-w-5xl px-4 py-14">
          <div className="mx-auto max-w-xl text-center">
            <h2 className="text-2xl font-bold tracking-tight md:text-3xl text-balance">
              Three steps to your first code
            </h2>
          </div>
          <div className="mt-10 grid gap-4 md:grid-cols-3">
            {steps.map((s) => (
              <div key={s.n} className="relative rounded-2xl border border-border bg-card p-6">
                <span className="grid size-9 place-items-center rounded-full bg-primary font-mono text-sm font-semibold text-primary-foreground">
                  {s.n}
                </span>
                <h3 className="mt-4 font-semibold">{s.title}</h3>
                <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">{s.body}</p>
              </div>
            ))}
          </div>
        </section>

        {/* CTA */}
        <section className="mx-auto w-full max-w-5xl px-4 pb-16">
          <div className="relative overflow-hidden rounded-3xl bg-primary px-6 py-12 text-center text-primary-foreground">
            <div className="mx-auto flex max-w-lg flex-col items-center gap-4">
              <Lock className="size-8" />
              <h2 className="text-2xl font-bold tracking-tight md:text-3xl text-balance">
                Ready to build reliable sign-in flows?
              </h2>
              <p className="text-pretty text-primary-foreground/80">
                Create your OlaqVerify account and send your first simulated message in seconds.
              </p>
              <Button asChild size="lg" variant="secondary" className="mt-2">
                <Link href="/sign-up">
                  Create free account
                  <ArrowRight />
                </Link>
              </Button>
            </div>
          </div>
        </section>
      </main>

      <footer className="border-t border-border">
        <div className="mx-auto flex w-full max-w-5xl flex-col items-center justify-between gap-4 px-4 py-8 sm:flex-row">
          <Logo size="sm" />
          <p className="text-center text-xs text-muted-foreground">
            OlaqVerify is a testing sandbox using simulated data. It is not a tool for
            bypassing third-party verification.
          </p>
        </div>
      </footer>
    </div>
  )
}
