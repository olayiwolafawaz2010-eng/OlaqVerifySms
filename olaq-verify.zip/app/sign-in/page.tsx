import { redirect } from "next/navigation"
import { getSession } from "@/lib/session"
import { AuthForm } from "@/components/auth-form"
import { AuthShell } from "@/components/auth-shell"

export default async function SignInPage() {
  const session = await getSession()
  if (session?.user) redirect("/dashboard")

  return (
    <AuthShell title="Welcome back" subtitle="Log in to your OlaqVerify workspace.">
      <AuthForm mode="sign-in" />
    </AuthShell>
  )
}
