"use server"

import { db } from "@/lib/db"
import { wallet, transaction } from "@/lib/db/schema"
import { getUserId } from "@/lib/session"
import { desc, eq, sql } from "drizzle-orm"
import { revalidatePath } from "next/cache"

export async function getWallet() {
  const userId = await getUserId()
  const rows = await db.select().from(wallet).where(eq(wallet.userId, userId))
  if (rows.length === 0) {
    const inserted = await db
      .insert(wallet)
      .values({ userId, balance: 0 })
      .onConflictDoNothing()
      .returning()
    return inserted[0] ?? { userId, balance: 0, updatedAt: new Date() }
  }
  return rows[0]
}

export async function getTransactions() {
  const userId = await getUserId()
  return db
    .select()
    .from(transaction)
    .where(eq(transaction.userId, userId))
    .orderBy(desc(transaction.createdAt))
    .limit(50)
}

const ALLOWED_AMOUNTS = [500, 1000, 2500, 5000, 10000]

export async function addFunds(amountCents: number) {
  const userId = await getUserId()

  // Server-side validation: only permit known top-up amounts.
  if (!ALLOWED_AMOUNTS.includes(amountCents)) {
    throw new Error("Invalid top-up amount")
  }

  await db
    .insert(wallet)
    .values({ userId, balance: amountCents, updatedAt: new Date() })
    .onConflictDoUpdate({
      target: wallet.userId,
      set: {
        balance: sql`${wallet.balance} + ${amountCents}`,
        updatedAt: new Date(),
      },
    })

  await db.insert(transaction).values({
    userId,
    type: "credit",
    amount: amountCents,
    description: "Wallet top-up (simulated)",
  })

  revalidatePath("/dashboard")
  revalidatePath("/dashboard/wallet")
}
