"use server"

import { db } from "@/lib/db"
import { project, message, wallet, transaction } from "@/lib/db/schema"
import { getUserId } from "@/lib/session"
import {
  TEST_SERVICES,
  randomTestNumber,
  randomOtp,
  randomSender,
  buildOtpMessage,
} from "@/lib/simulate"
import { and, desc, eq, sql } from "drizzle-orm"
import { revalidatePath } from "next/cache"

const PROJECT_COST = 100 // cents, charged per simulated project

export async function getProjects() {
  const userId = await getUserId()
  return db
    .select()
    .from(project)
    .where(eq(project.userId, userId))
    .orderBy(desc(project.createdAt))
}

export async function createProject(name: string, service: string) {
  const userId = await getUserId()

  const cleanName = name.trim().slice(0, 60)
  if (!cleanName) throw new Error("Project name is required")
  if (!TEST_SERVICES.includes(service as (typeof TEST_SERVICES)[number])) {
    throw new Error("Unknown service")
  }

  // Charge the wallet for provisioning a simulated test number.
  const walletRows = await db
    .select()
    .from(wallet)
    .where(eq(wallet.userId, userId))
  const balance = walletRows[0]?.balance ?? 0
  if (balance < PROJECT_COST) {
    throw new Error("Insufficient wallet balance")
  }

  await db
    .update(wallet)
    .set({ balance: sql`${wallet.balance} - ${PROJECT_COST}`, updatedAt: new Date() })
    .where(eq(wallet.userId, userId))

  await db.insert(transaction).values({
    userId,
    type: "debit",
    amount: PROJECT_COST,
    description: `Test number for ${cleanName} (simulated)`,
  })

  const inserted = await db
    .insert(project)
    .values({
      userId,
      name: cleanName,
      service,
      phoneNumber: randomTestNumber(),
      status: "active",
    })
    .returning()

  revalidatePath("/dashboard/projects")
  revalidatePath("/dashboard")
  return inserted[0]
}

export async function getMessages() {
  const userId = await getUserId()
  return db
    .select()
    .from(message)
    .where(eq(message.userId, userId))
    .orderBy(desc(message.receivedAt))
    .limit(100)
}

// Simulate an inbound OTP message arriving for one of the user's test projects.
export async function simulateIncomingMessage(projectId: number) {
  const userId = await getUserId()

  const rows = await db
    .select()
    .from(project)
    .where(and(eq(project.id, projectId), eq(project.userId, userId)))
  const proj = rows[0]
  if (!proj) throw new Error("Project not found")

  const code = randomOtp()
  const inserted = await db
    .insert(message)
    .values({
      userId,
      projectId,
      sender: randomSender(),
      body: buildOtpMessage(proj.service, code),
      otpCode: code,
    })
    .returning()

  revalidatePath("/dashboard/inbox")
  return inserted[0]
}

export async function deleteMessage(id: number) {
  const userId = await getUserId()
  await db.delete(message).where(and(eq(message.id, id), eq(message.userId, userId)))
  revalidatePath("/dashboard/inbox")
}
