import { redirect } from "next/navigation"
import { getSession } from "@/lib/session"
import { getWallet } from "@/app/actions/wallet"
import { Sidebar } from "@/components/dashboard/sidebar"
import { BottomNav } from "@/components/dashboard/bottom-nav"
import { TopBar } from "@/components/dashboard/top-bar"

export default async function DashboardLayout({
  children,
}: {
  children: React.ReactNode
}) {
  const session = await getSession()
  if (!session?.user) redirect("/sign-in")

  const wallet = await getWallet()

  return (
    <div className="flex min-h-dvh bg-secondary/20">
      <Sidebar />
      <div className="flex min-w-0 flex-1 flex-col">
        <TopBar
          name={session.user.name ?? "there"}
          email={session.user.email}
          balance={wallet.balance}
        />
        <main className="flex-1 px-4 pb-24 pt-5 md:pb-8">
          <div className="mx-auto w-full max-w-3xl">{children}</div>
        </main>
      </div>
      <BottomNav />
    </div>
  )
}
