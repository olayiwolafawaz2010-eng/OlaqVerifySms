import { ArrowDownLeft, ArrowUpRight } from "lucide-react"
import { getWallet, getTransactions } from "@/app/actions/wallet"
import { PageHeading } from "@/components/dashboard/page-heading"
import { BalanceCard } from "@/components/dashboard/balance-card"
import { AddFunds } from "@/components/dashboard/add-funds"
import { formatCurrency, formatDate } from "@/lib/format"
import { cn } from "@/lib/utils"

export default async function WalletPage() {
  const [wallet, transactions] = await Promise.all([getWallet(), getTransactions()])

  return (
    <div className="flex flex-col gap-6">
      <PageHeading title="Wallet" description="Manage your prepaid testing balance." />

      <BalanceCard balance={wallet.balance} />
      <AddFunds />

      <div>
        <h2 className="mb-3 text-sm font-semibold text-muted-foreground">
          Recent transactions
        </h2>
        {transactions.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-card/50 p-6 text-center">
            <p className="text-sm text-muted-foreground">No transactions yet.</p>
          </div>
        ) : (
          <ul className="flex flex-col gap-2">
            {transactions.map((t) => {
              const credit = t.type === "credit"
              return (
                <li
                  key={t.id}
                  className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3.5"
                >
                  <span
                    className={cn(
                      "grid size-9 shrink-0 place-items-center rounded-full",
                      credit
                        ? "bg-success/10 text-success"
                        : "bg-destructive/10 text-destructive",
                    )}
                  >
                    {credit ? (
                      <ArrowDownLeft className="size-4" />
                    ) : (
                      <ArrowUpRight className="size-4" />
                    )}
                  </span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">{t.description}</p>
                    <p className="text-xs text-muted-foreground">
                      {formatDate(t.createdAt)}
                    </p>
                  </div>
                  <span
                    className={cn(
                      "font-mono text-sm font-semibold",
                      credit ? "text-success" : "text-foreground",
                    )}
                  >
                    {credit ? "+" : "-"}
                    {formatCurrency(t.amount)}
                  </span>
                </li>
              )
            })}
          </ul>
        )}
      </div>
    </div>
  )
}
