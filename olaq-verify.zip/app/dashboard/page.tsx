import Link from "next/link"
import { Inbox, FlaskConical, Plus, Receipt, ArrowRight } from "lucide-react"
import { getSession } from "@/lib/session"
import { getWallet } from "@/app/actions/wallet"
import { getProjects, getMessages } from "@/app/actions/projects"
import { BalanceCard } from "@/components/dashboard/balance-card"
import { timeAgo } from "@/lib/format"

const quickActions = [
  { href: "/dashboard/projects", label: "New project", icon: FlaskConical },
  { href: "/dashboard/inbox", label: "Open inbox", icon: Inbox },
  { href: "/dashboard/wallet", label: "Add funds", icon: Plus },
  { href: "/dashboard/orders", label: "History", icon: Receipt },
]

export default async function DashboardHome() {
  const session = await getSession()
  const [wallet, projects, messages] = await Promise.all([
    getWallet(),
    getProjects(),
    getMessages(),
  ])

  const firstName = (session?.user.name ?? "there").split(" ")[0]

  const stats = [
    { label: "Active projects", value: projects.length },
    { label: "Messages received", value: messages.length },
  ]

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Hi {firstName}</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Here&apos;s what&apos;s happening in your testing sandbox.
        </p>
      </div>

      <BalanceCard balance={wallet.balance} />

      <div className="grid grid-cols-2 gap-3">
        {stats.map((s) => (
          <div key={s.label} className="rounded-2xl border border-border bg-card p-4">
            <p className="font-mono text-3xl font-bold">{s.value}</p>
            <p className="mt-0.5 text-sm text-muted-foreground">{s.label}</p>
          </div>
        ))}
      </div>

      <div>
        <h2 className="mb-3 text-sm font-semibold text-muted-foreground">Quick actions</h2>
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          {quickActions.map((a) => (
            <Link
              key={a.href}
              href={a.href}
              className="flex flex-col items-center gap-2 rounded-2xl border border-border bg-card p-4 text-center transition-all hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-md hover:shadow-primary/5"
            >
              <span className="grid size-10 place-items-center rounded-xl bg-accent text-accent-foreground">
                <a.icon className="size-5" />
              </span>
              <span className="text-xs font-medium">{a.label}</span>
            </Link>
          ))}
        </div>
      </div>

      <div>
        <div className="mb-3 flex items-center justify-between">
          <h2 className="text-sm font-semibold text-muted-foreground">Recent messages</h2>
          <Link
            href="/dashboard/inbox"
            className="inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline"
          >
            View all <ArrowRight className="size-3.5" />
          </Link>
        </div>
        {messages.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-card/50 p-6 text-center">
            <p className="text-sm text-muted-foreground">
              No messages yet. Create a project and simulate an incoming code.
            </p>
          </div>
        ) : (
          <ul className="flex flex-col gap-2">
            {messages.slice(0, 3).map((m) => (
              <li
                key={m.id}
                className="flex items-center gap-3 rounded-2xl border border-border bg-card p-3.5"
              >
                <span className="grid size-9 shrink-0 place-items-center rounded-lg bg-accent text-xs font-semibold text-accent-foreground">
                  {m.sender.slice(0, 2)}
                </span>
                <div className="min-w-0 flex-1">
                  <p className="truncate text-sm">{m.body}</p>
                  <p className="text-xs text-muted-foreground">{timeAgo(m.receivedAt)}</p>
                </div>
                {m.otpCode && (
                  <span className="rounded-lg bg-secondary px-2 py-1 font-mono text-sm font-semibold">
                    {m.otpCode}
                  </span>
                )}
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  )
}
