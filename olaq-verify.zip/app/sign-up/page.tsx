import { redirect } from "next/navigation"
import { getSession } from "@/lib/session"
import { AuthForm } from "@/components/auth-form"
import { AuthShell } from "@/components/auth-shell"

export default async function SignUpPage() {
  const session = await getSession()
  if (session?.user) redirect("/dashboard")

  return (
    <AuthShell
      title="Create your account"
      subtitle="Start testing SMS and OTP flows in a safe sandbox."
    >
      <AuthForm mode="sign-up" />
    </AuthShell>
  )
}
