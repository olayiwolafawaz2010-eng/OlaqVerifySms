// All data here is SIMULATED for development/testing of SMS delivery UIs.
// No real carriers, phone numbers, or third-party verification systems are involved.

// Reserved, non-routable test ranges (555 line numbers are reserved for fictional use).
export const TEST_SERVICES = [
  "Acme Auth",
  "DevBox",
  "TestPay",
  "SampleApp",
  "QA Portal",
  "Sandbox ID",
] as const

export function randomTestNumber() {
  const area = 555
  const prefix = String(Math.floor(100 + Math.random() * 900))
  const line = String(Math.floor(1000 + Math.random() * 9000))
  return `+1 (${area}) ${prefix}-${line}`
}

export function randomOtp() {
  return String(Math.floor(100000 + Math.random() * 900000))
}

const SENDERS = ["VERIFY", "OTP", "AUTHMSG", "NOTICE", "SANDBOX"]

export function randomSender() {
  return SENDERS[Math.floor(Math.random() * SENDERS.length)]
}

export function buildOtpMessage(service: string, code: string) {
  const templates = [
    `Your ${service} verification code is ${code}. It expires in 10 minutes.`,
    `[${service}] ${code} is your one-time passcode. Do not share it.`,
    `${code} is your ${service} login code. Reply STOP to opt out.`,
    `Use code ${code} to finish signing in to ${service}.`,
  ]
  return templates[Math.floor(Math.random() * templates.length)]
}
