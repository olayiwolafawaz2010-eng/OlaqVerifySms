import { MessageSquare, ShieldCheck } from "lucide-react"

const previewMessages = [
  { sender: "VERIFY", body: "Your Acme Auth code is 481920. Expires in 10 min.", code: "481920", time: "now" },
  { sender: "OTP", body: "204517 is your TestPay one-time passcode.", code: "204517", time: "2m" },
  { sender: "SANDBOX", body: "Use code 739104 to finish signing in to DevBox.", code: "739104", time: "5m" },
]

export function PhoneMockup() {
  return (
    <div className="relative mx-auto w-full max-w-[280px]">
      <div className="rounded-[2.5rem] border border-border bg-card p-2.5 shadow-2xl shadow-primary/10">
        <div className="overflow-hidden rounded-[2rem] bg-secondary/60">
          <div className="flex items-center justify-between bg-primary px-5 py-3 text-primary-foreground">
            <span className="inline-flex items-center gap-2 text-sm font-medium">
              <MessageSquare className="size-4" /> Test Inbox
            </span>
            <span className="rounded-full bg-primary-foreground/20 px-2 py-0.5 text-[11px] font-medium">
              Live
            </span>
          </div>
          <div className="flex flex-col gap-2.5 p-3">
            {previewMessages.map((m) => (
              <div key={m.code} className="rounded-2xl bg-card p-3 shadow-sm">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-semibold text-foreground">{m.sender}</span>
                  <span className="text-[11px] text-muted-foreground">{m.time}</span>
                </div>
                <p className="mt-1 text-[13px] leading-snug text-muted-foreground">{m.body}</p>
                <div className="mt-2 inline-flex items-center gap-1.5 rounded-lg bg-accent px-2 py-1">
                  <ShieldCheck className="size-3.5 text-accent-foreground" />
                  <span className="font-mono text-sm font-semibold tracking-widest text-accent-foreground">
                    {m.code}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
