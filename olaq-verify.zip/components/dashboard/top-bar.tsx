import Link from "next/link"
import { Wallet } from "lucide-react"
import { Logo } from "@/components/logo"
import { formatCurrency } from "@/lib/format"
import {
  Avatar,
  AvatarFallback,
} from "@/components/ui/avatar"

export function TopBar({
  name,
  email,
  balance,
}: {
  name: string
  email: string
  balance: number
}) {
  const initials = name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase()

  return (
    <header className="sticky top-0 z-30 flex h-16 items-center justify-between gap-3 border-b border-border bg-background/90 px-4 backdrop-blur-md">
      <div className="md:hidden">
        <Link href="/dashboard" aria-label="OlaqVerify home">
          <Logo showText={false} />
        </Link>
      </div>
      <div className="hidden md:block">
        <p className="text-sm text-muted-foreground">Welcome back,</p>
        <p className="-mt-0.5 font-semibold">{name}</p>
      </div>

      <div className="flex items-center gap-3">
        <Link
          href="/dashboard/wallet"
          className="inline-flex items-center gap-2 rounded-full border border-border bg-secondary/60 px-3 py-1.5 text-sm font-medium transition-colors hover:bg-secondary"
        >
          <Wallet className="size-4 text-primary" />
          <span className="font-mono">{formatCurrency(balance)}</span>
        </Link>
        <Link href="/dashboard/profile" aria-label="Profile">
          <Avatar className="size-9 border border-border">
            <AvatarFallback className="bg-primary text-primary-foreground text-xs font-semibold">
              {initials || "OV"}
            </AvatarFallback>
          </Avatar>
        </Link>
      </div>
    </header>
  )
}
