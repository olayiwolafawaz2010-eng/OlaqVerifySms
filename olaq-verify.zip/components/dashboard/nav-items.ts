import { LayoutDashboard, Inbox, FlaskConical, Wallet, Receipt, User } from "lucide-react"

export const navItems = [
  { href: "/dashboard", label: "Home", icon: LayoutDashboard },
  { href: "/dashboard/inbox", label: "Inbox", icon: Inbox },
  { href: "/dashboard/projects", label: "Projects", icon: FlaskConical },
  { href: "/dashboard/wallet", label: "Wallet", icon: Wallet },
  { href: "/dashboard/orders", label: "History", icon: Receipt },
  { href: "/dashboard/profile", label: "Profile", icon: User },
]
