import Link from "next/link"
import { Plus, Wallet } from "lucide-react"
import { formatCurrency } from "@/lib/format"
import { Button } from "@/components/ui/button"

export function BalanceCard({ balance }: { balance: number }) {
  return (
    <div className="relative overflow-hidden rounded-3xl bg-primary p-6 text-primary-foreground shadow-lg shadow-primary/20">
      <div className="pointer-events-none absolute -right-8 -top-10 size-40 rounded-full bg-primary-foreground/10" />
      <div className="pointer-events-none absolute -bottom-12 -left-6 size-36 rounded-full bg-primary-foreground/5" />
      <div className="relative flex items-center justify-between">
        <span className="inline-flex items-center gap-2 text-sm font-medium text-primary-foreground/80">
          <Wallet className="size-4" /> Wallet balance
        </span>
      </div>
      <p className="relative mt-3 font-mono text-4xl font-bold tracking-tight">
        {formatCurrency(balance)}
      </p>
      <div className="relative mt-5 flex gap-2">
        <Button asChild variant="secondary" size="sm">
          <Link href="/dashboard/wallet">
            <Plus className="size-4" /> Add funds
          </Link>
        </Button>
        <Button
          asChild
          size="sm"
          variant="ghost"
          className="text-primary-foreground hover:bg-primary-foreground/15 hover:text-primary-foreground"
        >
          <Link href="/dashboard/orders">View history</Link>
        </Button>
      </div>
    </div>
  )
}
