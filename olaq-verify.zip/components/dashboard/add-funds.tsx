"use client"

import { useState, useTransition } from "react"
import { useRouter } from "next/navigation"
import { Plus, Loader2, Check } from "lucide-react"
import { addFunds } from "@/app/actions/wallet"
import { formatCurrency } from "@/lib/format"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { toast } from "sonner"

const AMOUNTS = [500, 1000, 2500, 5000, 10000]

export function AddFunds() {
  const router = useRouter()
  const [selected, setSelected] = useState(1000)
  const [pending, startTransition] = useTransition()

  function handleAdd() {
    startTransition(async () => {
      try {
        await addFunds(selected)
        toast.success(`${formatCurrency(selected)} added to your wallet`)
        router.refresh()
      } catch {
        toast.error("Could not add funds. Please try again.")
      }
    })
  }

  return (
    <div className="rounded-2xl border border-border bg-card p-5">
      <h2 className="font-semibold">Add funds</h2>
      <p className="mt-1 text-sm text-muted-foreground">
        Top up your prepaid balance. Amounts are simulated for testing.
      </p>

      <div className="mt-4 grid grid-cols-3 gap-2.5">
        {AMOUNTS.map((amount) => {
          const active = selected === amount
          return (
            <button
              key={amount}
              type="button"
              onClick={() => setSelected(amount)}
              className={cn(
                "relative rounded-xl border p-3 text-center transition-all",
                active
                  ? "border-primary bg-primary/5 ring-2 ring-primary/20"
                  : "border-border hover:border-primary/40",
              )}
            >
              {active && (
                <Check className="absolute right-1.5 top-1.5 size-3.5 text-primary" />
              )}
              <span className="font-mono text-base font-semibold">
                {formatCurrency(amount)}
              </span>
            </button>
          )
        })}
      </div>

      <Button onClick={handleAdd} disabled={pending} size="lg" className="mt-4 w-full">
        {pending ? <Loader2 className="animate-spin" /> : <Plus />}
        Add {formatCurrency(selected)}
      </Button>
    </div>
  )
}
