import { ShieldCheck } from "lucide-react"
import { cn } from "@/lib/utils"

export function Logo({
  className,
  showText = true,
  size = "md",
}: {
  className?: string
  showText?: boolean
  size?: "sm" | "md" | "lg"
}) {
  const box = size === "sm" ? "size-7" : size === "lg" ? "size-11" : "size-9"
  const icon = size === "sm" ? "size-4" : size === "lg" ? "size-6" : "size-5"
  const text = size === "sm" ? "text-base" : size === "lg" ? "text-2xl" : "text-lg"

  return (
    <span className={cn("inline-flex items-center gap-2", className)}>
      <span
        className={cn(
          "grid place-items-center rounded-xl bg-primary text-primary-foreground shadow-sm shadow-primary/30",
          box,
        )}
      >
        <ShieldCheck className={icon} strokeWidth={2.4} />
      </span>
      {showText && (
        <span className={cn("font-semibold tracking-tight", text)}>
          Olaq<span className="text-primary">Verify</span>
        </span>
      )}
    </span>
  )
}
