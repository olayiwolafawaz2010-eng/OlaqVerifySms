import Link from "next/link"
import { Logo } from "@/components/logo"

export function AuthShell({
  title,
  subtitle,
  children,
}: {
  title: string
  subtitle: string
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-dvh flex-col bg-secondary/30">
      <header className="mx-auto flex w-full max-w-md items-center px-4 py-6">
        <Link href="/" aria-label="OlaqVerify home">
          <Logo />
        </Link>
      </header>
      <main className="flex flex-1 items-start justify-center px-4 pb-10">
        <div className="w-full max-w-md">
          <div className="rounded-3xl border border-border bg-card p-6 shadow-xl shadow-primary/5 sm:p-8 animate-in fade-in slide-in-from-bottom-2 duration-500">
            <h1 className="text-2xl font-bold tracking-tight text-balance">{title}</h1>
            <p className="mt-1.5 text-sm text-muted-foreground text-pretty">{subtitle}</p>
            <div className="mt-6">{children}</div>
          </div>
        </div>
      </main>
    </div>
  )
}
